<!DOCTYPE html>
<html>
<head>
	<title>BMS</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
	
	
</head>
<body>
	<div id="full">
		<div  style="background-image: url('img/bms.jpg');background-size: 100% 710px; width: 100%; height: 710px">
		<div id="header">
			<div id="logo">
				<h1><font color="white">My Project</font></h1>
			</div>
			<div id="cl"><input type="button" name="btn" id="btn"></div>
			<div id="nav">
				<ul id="a1">
					<li><a href="#">Home</a></li>
					<li><a href="#">Contect Us</a></li>
					<li><a href="#">BOOK MY STAY</a></li>
					<li><a href="#">Our Hotel</a></li>
					<li><a href="#">Help</a></li>
				</ul>
			</div>
		</div>
		<div id="banner"><br><br><br><br><br><br><br><br><br><br>
			<center><div style="background:rgba(255,255,255,.5); width: 80%;height: 400px;">
				<h2 align="left" style="color: red;padding: 10px;s">CONTACT INFORMATION</h2>
				<a href="#"><h3 align="left" style="color: green">Hotels</h3></a>
                <a href="#"><h3 align="left" style="color: green">Corporate Office</h3></a>
                <a href="#"><h3 align="left" style="color: green">Global Sales Office</h3></a>
               <h2 align="left" style="color: red;padding: 10px;s"> PROVIDE YOUR VALUABLE FEEDBACK</h2>
                <a href="#"><h3 align="left" style="color: green">Hotel feedback and suggestions</h3></a>
                <a href="#"><h3 align="left" style="color: green">Website feedback and suggestions</h3></a>
			</div>
		</div>
	
	
		
		
	
	
	</center>
	</div>
  </div>
</body>

</html>