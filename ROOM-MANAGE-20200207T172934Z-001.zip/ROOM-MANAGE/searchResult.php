<?php
include("connection.php");
// $r=$_GET['room'];
//$ci=$_GET['ci'];
$status=$_GET['status'];
$cid=$_GET['cid'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home (ROOM Management)</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
</head>
<body>
	<div id="full">
		<div id="bg" style="background-color:#bdc3c7; height: 1200px;">
 	<div id="header">
			<div id="logo">
				<h1><font color="white">My Project</font></h1>
			</div>
			<div id="nav">
				<ul>
					<li><a href="DOSearch.php">Home Page</a></li>
				</ul>
			</div>
		</div>
    	<div id="banner">
			<div id="form">
				<form action="SearchResult.php" method="post">
			<table style="color: yellow;">
			</div>
		<div id="banner">
			<div style="background-color: rgba(255,255,255,0.6);">
			<table>
			<!--	<tr>
				    <th width="10%" height="50px">BID</th>
					<th width="10%" height="50px">RID</th>
                     <th width="10%" height="50px">DATE</th>
                     <th width="10%" height="50px">STIME</th>
                     <th width="10%" height="50px">ETIME</th>
					 <th width="10%" height="50px">SEC</th>
                     <th width="10%" height="50px">CID</th>
                     <th width="10%" height="50px">FID</th>
                     <th width="10%" height="50px">STATUS</th>
					 <th width="10%" height="50px">DELETE</th>
					 <th width="10%" height="50px">Cancel Booking</th>
				</tr>
			-->	<?php
                 $q1="select * from newbooking";
               //  $run=mysqli_query($a,$q1);
              /*   while($row=mysqli_fetch_array($run))
                 {
					$bid=$row['BID'];
					$rno=$row['RID'];
					$date=$row['DATE'];
					$stime=$row['STIME'];
					$etime=$row['ETIME'];
					$sec=$row['SEC'];
					$cid=$row['CID'];
					$fid=$row['FID'];
					$rbk=$row['STATUS'];*/
                ?>

			<!--	<tr>
				     <td width="10%" height="50px"><center><?php echo $bid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $rno; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $date; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $stime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $etime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $sec; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $cid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $fid; ?><center></td>
					<td width="10%" height="50px"><center><?php echo $rbk; ?><center></td>
				<!--	<td><a style="color: blue" href="deleteEXTRAbook.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>">Delete row Completyly</a> </td>
					<td><a style="color: blue" href="CancelBooking.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>&bid=<?php echo $bid;?>&date=<?php echo $date;?>&etime=<?php echo $etime;?>&sec=<?php echo $sec;?>&fid=<?php echo $fid;?>&cid=<?php echo $cid;?>&rbk=<?php echo $rbk;?>">Cancel Booking</a> </td>										
		            
			-->	</tr>
			-->	<?php
				 // }
				?>
			</table>
		</center>
		</div>
	<center>
	
	</center>
	</div>
	
				<?php
	if($status=="REGULAR-CLASS")
    {
         if($status=="REGULAR-CLASS" AND $cid=="")
    {
		echo '<script type="text/javascript">alert("Please go to homepage and fill up the COURSE ID ")</script>';
		echo("<script>window.location.href = 'DOsearch.php';</script>");
	}		
				  $q1="select * from roominfo where CID='$cid'";
                        $run=mysqli_query($a,$q1);
                        $row=mysqli_fetch_array($run);
                        $cidfromtable=$row['CID'];
						//echo $cidfromtable; //will show the room number;
                        $q="select * from room where status='unbook'";
                        $run=mysqli_query($a,$q);
                        $num=mysqli_num_rows($run);/*num*/
                        if($cidfromtable==$cid)       //<---------------comparing here that existing room and order room 
                        {
                        	?>
                 <!--       	<tr>
					<td>Status</td>
					<td><input type="text" name="Status" value="Available-class" disabled="disabled" title="Status"></td>
				</tr>
				<tr>-->
		<div id="banner">
			<h1 style="color:blue;text-align: center; ">REGULAR CLASS ROUTINE</h1>
			<div style="background-color: rgba(255,255,255,0.6);">
			<table>
				<tr>
				    <th width="10%" height="50px">BID1</th>
					<th width="10%" height="50px">RID</th>
                     <th width="10%" height="50px">DATE</th>
                     <th width="10%" height="50px">STIME</th>
                     <th width="10%" height="50px">ETIME</th>
					 <th width="10%" height="50px">SEC</th>
                     <th width="10%" height="50px">CID</th>
                     <th width="10%" height="50px">FID</th>
                     <th width="10%" height="50px">STATUS</th>
					 <th width="10%" height="50px">DELETE</th>
					 <th width="10%" height="50px">Cancel Booking</th>
				</tr>
				<?php
				 
                 $q1="select * from roominfo where CID='$cid'";
                 $run=mysqli_query($a,$q1);
                 while($row=mysqli_fetch_array($run))
                 {
					$bid=$row['BID'];
					$rno=$row['RID'];
					$date=$row['DATE'];
					$stime=$row['STIME'];
					$etime=$row['ETIME'];
					$sec=$row['SEC'];
					$cid=$row['CID'];
					$fid=$row['FID'];
					$rbk=$row['STATUS'];
                ?>

				<tr>
				     <td width="10%" height="50px"><center><?php echo $bid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $rno; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $date; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $stime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $etime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $sec; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $cid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $fid; ?><center></td>
					<td width="10%" height="50px"><center><?php echo $rbk; ?><center></td>
					<td><a style="color: blue" href="deleteEXTRAbook.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>">Delete row completely</a> </td>
					<td><a style="color: blue" href="CancelBooking.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>&bid=<?php echo $bid;?>&date=<?php echo $date;?>&etime=<?php echo $etime;?>&sec=<?php echo $sec;?>&fid=<?php echo $fid;?>&cid=<?php echo $cid;?>&rbk=<?php echo $rbk;?>">Cancel Booking</a> </td>										
		            
				</tr>
				<?php
				  }
				?>
			</table>
		</center>
		</div>
	<center>
	
	</center>
	</div>
                    <?php    }
                    else              //<---------if order room is much more than existing room then we will show not available.
                    {
						echo '<script type="text/javascript">alert("No Such information exist please go back to homepage")</script>';
                    	?>
                           <tr>
					<td>Status</td>
					<td><input type="text" name="Status" value="Not-Available" disabled="disabled" title="Status">
					</td>
                    
					
				</tr>          
                    	<?php
                    }
	} ///IF(REGULAR)	
     else if($cid=="")    ///else if searching for extra info   <---------------------------------------------------------------------------------------------------
	{
					
				  $q1="select * from newbooking where STATUS='$status'";
                        $run=mysqli_query($a,$q1);
                        $row=mysqli_fetch_array($run);
                        $statusfromtable=$row['STATUS'];
						$cidfromtable=$row['CID'];
						 echo $statusfromtable; //will show the room number;
                        $q="select * from room where status='unbook'";
                        $run=mysqli_query($a,$q);
                        $num=mysqli_num_rows($run);/*num*/
                        if($statusfromtable==$status)       //<---------------comparing here that existing room and order room 
                        {
                        	?>
                 <!--       	<tr>
					<td>Status</td>
					<td><input type="text" name="Status" value="Available-class" disabled="disabled" title="Status"></td>
				</tr>
				<tr>-->
		<div id="banner">
			<h1 style="color:blue;text-align: center; ">EXTRA SCHEDULE</h1>
			<div style="background-color: rgba(255,255,255,0.6);">
			<table>
				<tr>
				    <th width="10%" height="50px">BID1</th>
					<th width="10%" height="50px">RID</th>
                     <th width="10%" height="50px">DATE</th>
                     <th width="10%" height="50px">STIME</th>
                     <th width="10%" height="50px">ETIME</th>
					 <th width="10%" height="50px">SEC</th>
                     <th width="10%" height="50px">CID</th>
                     <th width="10%" height="50px">FID</th>
                     <th width="10%" height="50px">STATUS</th>
					 <th width="10%" height="50px">DELETE</th>
					 <th width="10%" height="50px">Cancel Booking</th>
				</tr>
				<?php
				 
                 $q1="select * from newbooking where STATUS='$status'";
                 
				 $run=mysqli_query($a,$q1);
                 while($row=mysqli_fetch_array($run))
                {
					$bid=$row['BID'];
					$rno=$row['RID'];
					$date=$row['DATE'];
					$stime=$row['STIME'];
					$etime=$row['ETIME'];
					$sec=$row['SEC'];
					$cid=$row['CID'];
					$fid=$row['FID'];
					$rbk=$row['STATUS'];
                ?>

				<tr>
				     <td width="10%" height="50px"><center><?php echo $bid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $rno; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $date; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $stime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $etime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $sec; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $cid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $fid; ?><center></td>
					<td width="10%" height="50px"><center><?php echo $rbk; ?><center></td>
					<td><a style="color: blue" href="deleteEXTRAbook.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>">Delete row completely</a> </td>
					<td><a style="color: blue" href="CancelBooking.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>&bid=<?php echo $bid;?>&date=<?php echo $date;?>&etime=<?php echo $etime;?>&sec=<?php echo $sec;?>&fid=<?php echo $fid;?>&cid=<?php echo $cid;?>&rbk=<?php echo $rbk;?>">Cancel Booking</a> </td>										
		            
				</tr>
				<?php
				}
				?>
			</table>
		</center>
		</div>
	<center>
	
	</center>
	</div>
                    <?php    }
                    else              //<---------if order room is much more than existing room then we will show not available.
                    {
						echo '<script type="text/javascript">alert("No Such schedule exist please go back to homepage")</script>';
                    	?>
                           <tr>
					<td>Status</td>
					<td><input type="text" name="Status" value="Not-Available" disabled="disabled" title="Status">
					</td>
                    
					
				</tr>          
                    	<?php
                    }
	}  //else if($cid=="") end here
	  else //if($cid=="")    ///else if searching for extra info   <---------------------------------------------------------------------------------------------------
	{
					
				  $q1="select * from newbooking where STATUS='$status' And CID='$cid'";
                        $run=mysqli_query($a,$q1);
                        $row=mysqli_fetch_array($run);
                        $statusfromtable=$row['STATUS'];
						$cidfromtable=$row['CID'];
						 echo $statusfromtable; //will show the room number;
						 echo $cidfromtable;
                        $q="select * from room where status='unbook'";
                        $run=mysqli_query($a,$q);
                        $num=mysqli_num_rows($run);/*num*/
                        if($statusfromtable==$status)       //<---------------comparing here that existing room and order room 
                        {
                        	?>
                 <!--       	<tr>
					<td>Status</td>
					<td><input type="text" name="Status" value="Available-class" disabled="disabled" title="Status"></td>
				</tr>
				<tr>-->
		<div id="banner">
			<h1 style="color:blue;text-align: center; ">EXTRA SCHEDULE</h1>
			<div style="background-color: rgba(255,255,255,0.6);">
			<table>
				<tr>
				    <th width="10%" height="50px">BID1</th>
					<th width="10%" height="50px">RID</th>
                     <th width="10%" height="50px">DATE</th>
                     <th width="10%" height="50px">STIME</th>
                     <th width="10%" height="50px">ETIME</th>
					 <th width="10%" height="50px">SEC</th>
                     <th width="10%" height="50px">CID</th>
                     <th width="10%" height="50px">FID</th>
                     <th width="10%" height="50px">STATUS</th>
					 <th width="10%" height="50px">DELETE</th>
					 <th width="10%" height="50px">Cancel Booking</th>
				</tr>
				<?php
				 
                 $q1="select * from newbooking where STATUS='$status'";
                 
				 $run=mysqli_query($a,$q1);
                 while($row=mysqli_fetch_array($run))
                {
					$bid=$row['BID'];
					$rno=$row['RID'];
					$date=$row['DATE'];
					$stime=$row['STIME'];
					$etime=$row['ETIME'];
					$sec=$row['SEC'];
					$cid=$row['CID'];
					$fid=$row['FID'];
					$rbk=$row['STATUS'];
                ?>

				<tr>
				     <td width="10%" height="50px"><center><?php echo $bid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $rno; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $date; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $stime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $etime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $sec; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $cid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $fid; ?><center></td>
					<td width="10%" height="50px"><center><?php echo $rbk; ?><center></td>
					<td><a style="color: blue" href="deleteEXTRAbook.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>">Delete row completely</a> </td>
					<td><a style="color: blue" href="CancelBooking.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>&bid=<?php echo $bid;?>&date=<?php echo $date;?>&etime=<?php echo $etime;?>&sec=<?php echo $sec;?>&fid=<?php echo $fid;?>&cid=<?php echo $cid;?>&rbk=<?php echo $rbk;?>">Cancel Booking</a> </td>										
		            
				</tr>
				<?php
				}
				?>
			</table>
		</center>
		</div>
	<center>
	
	</center>
	</div>
                    <?php    }
                    else              //<---------if order room is much more than existing room then we will show not available.
                    {
						echo '<script type="text/javascript">alert("No Such schedule exist of that course please go back to homepage")</script>';
                    	?>
                           <tr>
					<td>Status</td>
					<td><input type="text" name="Status" value="Not-Available" disabled="disabled" title="Status">
					</td>
                    
					
				</tr>          
                    	<?php
                    }
	}  //2nd else if($cid=="") end here
	     
		
				?>
	
				
			</table>
		</form>
		
       
		</div>
		</div>
	</div>
	</div>
	
  </div>
</body>

</html>