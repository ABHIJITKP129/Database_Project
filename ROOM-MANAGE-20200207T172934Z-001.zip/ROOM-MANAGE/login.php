<?php
session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
	
	
</head>
<body>
	<div id="full">
		<div  style="background-image: url('img/bu.jpg');background-size: 100% 710px; width: 100%; height: 710px">
		<div id="header">
			<div id="logo">
				<h1><font color="white">Login Page</font></h1>
			</div>
			<div id="cl"><input type="button" name="btn" id="btn"></div>
			<div id="nav">
				<ul id="a1">
					<li><a href="index.php">Home</a></li>
					<li><a href="register.php">Register</a></li>
				</ul>
			</div>
		</div>
		<div id="banner"><br><br><br><br><br><br><br><br><br><br><br>
			<center><div style="background:rgba(255,255,255,.5); width: 80%;">
	       <form action="" method="post">
	       <table>
	       	<tr>
	       		<td width="50%" height="50px">Username</td>
	       		<td width="50%" height="50px"><input type="text" name="un" placeholder="Enter Username" title="Enter Username"></td>
	       	</tr>
	       		<tr>
	       		<td width="50%" height="50px">Password</td>
	       		<td width="50%" height="50px"><input type="password" name="ps" placeholder="Enter Password" title="Enter Password"></td>
	       	</tr>
	       	<tr>
	       		<td colspan="2"><input type="submit" name="sub" value="Login" style="width: 150px;height: 50px;border-radius: 30px;opacity: 0.8"></td>
	       	</tr>
	       </table>
		   
	       </form>
	       <?php
           if(isset($_POST['sub']))
           {
           	     $un=$_POST['un'];
           	     $ps=$_POST['ps'];
           	    //$q1="select * from admin";
				$q1="select * from admin WHERE un='$un' AND ps='$ps'";
				$q2="select * from faculty WHERE username='$un' AND password='$ps'";
           	    $run=mysqli_query($a,$q1);
				$run2=mysqli_query($a,$q2);
           	    $row=mysqli_fetch_array($run);
				$row2=mysqli_fetch_array($run2);
           	     $u=$row['un'];
           	     $p=$row['ps'];
				 
				 
				 $usernameF=$row2['username'];
           	     $passwordF=$row2['password'];
				 
           	   
				if($run)
				{
           	    // if($un=="admin" && $p="admin") //|| $un=="akp" && $p="akp123" )
				 if($un==$u && $ps==$p)
				 {
					$_SESSION['un'] = "$un";
				    $_SESSION['ps'] = "ps";
           	     //	header("Location:admin/ahome.php");
					echo("<script>window.location.href = 'admin/ahome.php';</script>");
           	     }
				 if($un==$usernameF && $p=$usernameF)
				 {
					 $_SESSION['username'] = $usernameF;
					 $_SESSION['password'] = $passwordF;
           	     	//header("Location:faculty/ahome.php");
					echo("<script>window.location.href = 'faculty/ahome.php';</script>");
           	     }
				 
           	     else
           	     {
           	     	//header("Location:index.php?Wrong User");
					//echo "you are not authorized,please register first";
           	     echo '<script type="text/javascript">alert("You are not authorized,please register first!")</script>';
				 }
				}
           }
           
	       ?>	
			<?php
			
			?>
	</div></center>
		</div>
	<center>
	
	</center>
	</div>
  </div>
</body>

</html>