<?php
include("connection.php");
$bid=$_GET['bid'];
$rno=$_GET['rno'];
//$stime=$_GET['stime'];
$date=$_GET['date'];
$stime=$_GET['stime'];
$etime=$_GET['etime'];
$sec=$_GET['sec'];
$cid=$_GET['cid'];
$fid=$_GET['fid'];
$rbk=$_GET['rbk'];
if(mysqli_query($a,"insert into newbooking(BID,RID,DATE,STIME,ETIME,SEC,CID,FID,STATUS) values('$bid','$rno','$date','$stime','$etime','$sec','$cid','$fid','$rbk')"))
				
{
if(mysqli_query($a,"DELETE FROM unbookedroom WHERE RID='$rno' AND STIME='$stime'"))//"update unbookedroom set BOOKEDFOR='unbook' where RID=$rno"))
{
	
	//header("Location:co.php");
	header("Location:unbookedRoom.php");
}
}
?>