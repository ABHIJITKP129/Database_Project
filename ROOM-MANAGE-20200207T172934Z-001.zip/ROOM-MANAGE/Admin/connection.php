<?php
$a=mysqli_connect('localhost','id9128359_unique99ap','123456789','id9128359_hd');
?>