<?php
include("connection.php");
$rno=$_GET['rno'];
$stime=$_GET['stime'];
if(mysqli_query($a,"DELETE from newbooking WHERE RID='$rno' AND STIME='$stime'"))//"update unbookedroom set BOOKEDFOR='unbook' where RID=$rno"))
{
	echo '<script type="text/javascript">alert("Data not updated in regular table!")</script>';
	//header("Location:co.php");
	header("Location:newBooking.php");
}
?>