<?php
session_start();
include("connection.php");
//$_POST['un']
?>
<!DOCTYPE html>
<html>
<head>
	<title>Logged in as <?php echo $_SESSION['un']; ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
</head>
<body style="background-color:#bdc3c7">
	<div id="full">
		<div id="bg" background-color:>
		<div id="header">
			<div id="logo">
				<h1><font color="white">DATA INSERT IN A TABLE</font></h1>
			</div>
			<div id="nav">
				<ul id="a1">
					<li><a href="ahome.php">Home</a></li>
					<li><a href="INSERTDATA.php">Insert Data</a></li>                          
					<li><a href="UpdateDATA.php">Update/Book</a></li>
					<li><a href="RegularRoutine.php">Routine</a></li>
					<li><a href="unbookedRoom.php">Unbooked Rooms</li>
					<li><a href="newBooking.php">New Booking</li>
					<li><a href="combieview.php">Combined view</li>
			<!--		<li><a href="http://localhost/ROOM-MANAGE/index.php">Help</a></li>
			-->	</ul>
			</div>
		</div>
		<div id="banner">
			<center><div id="form">
				<form action="INSERTDATA.php" method="post">
			<table style="color: black;">
				<tr>
					<td>BUILDING ID</td>
					<center><td width="100%" height="50px">
					<select name="bid">
						<option>UB01</option>
						<option>UB02</option>
					</select></center>
				</td>
				</tr>
				<tr>
					<td>Room ID</td>
				<!--	<td><input type="text" name="rno" placeholder="Enter Room No" title="Enter Room No" required></td>
				-->	
				<center><td width="100%" height="50px">
					<select name="rno" required>
						<option>10101</option>
						<option>10102</option>
						<option>10103</option>
						<option>10104</option>
						<option>10105</option>
						<option>20101</option>
						<option>20102</option>
						<option>20103</option>
						<option>20104</option>
						<option>20105</option>
					</select></center>
				</tr>
				
				<tr>
					<td>DATE</td>
					<td><input type="text" name="date" placeholder="Enter Date" title=" Enter Date" required></td>
					
				</tr>
				<tr>
					<td>Start Time</td>
				<!--	<td><input type="text" name="stime"></a>     -->
				<center><td width="100%" height="50px">
				<select name="stime">
						<option>8:00</option>
						<option>9:30</option>
						<option>11:00</option>
						<option>12:30</option>
						<option>2:00</option>
						<option>3:30</option>
						<option>5:00</option>
					</select></center>
					
				</tr>
				<tr>
					<td>End Time</td>
				<!--	<td><input type="text" name="etime"></a>  -->
				<center><td width="100%" height="50px">
				<select name="etime">
						<option>9:20</option>
						<option>10:50</option>
						<option>12:20</option>
						<option>1:50</option>
						<option>3:20</option>
						<option>4:50</option>
						<option>6:20</option>
					</select></center>
					
				</tr>
				<tr>
					<td>Section</td>
				<!--	<td><input type="number" name="sec" placeholder="Enter section No" title="Enter sec No"></td>
				-->
					<center><td width="100%" height="50px">
					<select name="sec">
					<option></option>
						<option>01</option>
						<option>02</option>
						<option>03</option>
						<option>04</option>
						<option>05</option>
						
					</select></center>
				</tr>
				<tr>
					<td>Course ID</td>
				<!--	<td><input type="text" name="cid" placeholder="Enter Course Id" title="Enter Course Id"></td>
				-->
					<center><td width="100%" height="50px">
					<select name="cid">
					<option></option>
						<option>cse110</option>
						<option>cse220</option>
						<option>cse370</option>
						<option>cse341</option>
						<option>cse420</option>
						
					</select></center>
				</tr>
				<tr>
					<td>Faculty ID</td>
					
				<!--	<td><input type="text" name="fid" placeholder="Enter faculty Id" title="Enter faculty Id"></td>
				-->	
					<td><input type="text" name="fid" value="<?php echo $_SESSION['un']; ?>" title="Enter faculty Id"></td>
				</tr>
				<tr>
					<td>Room Booked</td>
				<!--	<td><input type="text" name="Rbk" placeholder="Enter Room Booked status" title="Enter Room Booked status"></td>
				-->
						<center><td width="100%" height="50px">
					<select name="Rbk" required>
					<option></option>
						<option>REGULAR-CLASS</option>
						<option>UNBOOKED</option>
						<option>EXTRA-CLASS</option>
						<option>QUIZ</option>
						<option>SEMINAR</option>
						<option>WORKSHOP</option>
						
					</select></center>
				</tr>
				<tr>
				<td>
					<td><input style="width: 120px; height: 30px; border-radius: 20px; opacity: 1" type="submit" name="submit" value="submit"></td>
				</td>
				<!--<td>
					<td><input style="width: 120px; height: 30px; border-radius: 20px; opacity: 1" type="submit" name="submit" value="Update"></td>
				-->
				</td>
				</tr>
			</table>
		</form>
		<?php
        if(isset($_POST['submit']))
        {
         	$bid=$_POST['bid'];
			$rno=$_POST['rno'];
         	$date=$_POST['date'];
         	$stime=$_POST['stime'];
			$etime=$_POST['etime'];
         	$sec=$_POST['sec'];
         	$cid=$_POST['cid'];
			$fid=$_POST['fid'];
         	$rbk=$_POST['Rbk'];
			
			$q1="select * from roominfo where RID='$rno' AND STIME='$stime'";
			$q2="select * from unbookedroom where RID='$rno' AND STIME='$stime'";
			$run=mysqli_query($a,$q1);
			$run2=mysqli_query($a,$q2);
			//$row=mysqli_fetch_array($run);
			//$status=$row['STATUS'];
			
			

			if($rbk=="REGULAR-CLASS")
			{ 
				if($run)
				{
					if(mysqli_num_rows($run2)>0)
					{
										
					echo '<script type="text/javascript">alert("This slot Already exists in unbookedRoom.. Please try another ID!")</script>';
					}
					else if(mysqli_query($a,"insert into roominfo(BID,RID,DATE,STIME,ETIME,SEC,CID,FID,STATUS) values('$bid','$rno','$date','$stime','$etime','$sec','$cid','$fid','$rbk')"))
					{
						//echo "data inserted";
					echo '<script type="text/javascript">alert("Data inserted in ROOMINFO table!")</script>';
					}
					else
					{
						echo '<script type="text/javascript">alert("Data not inserted!")</script>';
					}
				}
				else
					{
						echo '<script type="text/javascript">alert("mysqli_query not working")</script>';
					}
				
			}
								
		    else if($rbk=="EXTRA-CLASS" || $rbk=="SEMINAR" || $rbk=="UNBOOKED" || $rbk=="QUIZ" || $rbk=="WORKSHOP")
			{
				if(mysqli_num_rows($run)>0)
				{
									
				echo '<script type="text/javascript">alert("This slot Already exists in regula class.. Please try another ID!")</script>';
				}
				else if(mysqli_query($a,"insert into unbookedroom(BID,RID,DATE,STIME,ETIME,SEC,CID,FID,BOOKEDFOR) values('$bid','$rno','$date','$stime','$etime','$sec','$cid','$fid','$rbk')"))
				{
					/*if(mysqli_query($a,"update unbookedroom set SEC='$sec',CID='$cid',FID='$fid',BOOKEDFOR='$rbk',DATE='$date' where RID='$rno' AND STIME='$stime' AND SEC='$sec'")) //values('$bid','$rno','$date','$stime','$etime','$sec','$cid','$fid','$rbk')"))
					{*/	
				echo '<script type="text/javascript">alert("Data inserted in unbooketable!")</script>';
				}
				else
				{
					echo '<script type="text/javascript">alert("Data not inserted unbooketable")</script>';
				}
			}
			else {
				echo '<script type="text/javascript">alert("Data not inserted in any table")</script>';
			}
        }

		?>
					</div></center>
		</div>
	</div>
	</div>
	
  </div>
</body>

</html>