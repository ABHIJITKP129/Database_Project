<?php
session_start();
include("connection.php");
//$_POST['un']
?>
<!DOCTYPE html>
<html>
<head>
	<title>Logged in as <?php echo $_SESSION['un']; ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
</head>
<body style="background-color:#bdc3c7">
	<div id="full">
		<div id="bg" background-color:>
		<div id="header">
			<div id="logo">
				<h1><font color="white">UPDATE EXISTING DATA</font></h1>
			</div>
			<div id="nav">
				<ul id="a1">
					<li><a href="ahome.php">Home</a></li>
					<li><a href="INSERTDATA.php">Insert Data</a></li>                          
					<li><a href="UpdateDATA.php">Update/Book Room</a></li>
					<li><a href="RegularRoutine.php">Routine</a></li>
					<li><a href="unbookedRoom.php">Unbooked Rooms</li>
					<li><a href="newBooking.php">New Booking Rooms</li>
					<li><a href="combieview.php">Combined view</li>
					<li><a href="rd.php">Room Details</a></li>
					<li><a href="http://localhost/Hotel2/index.php">Help</a></li>
				</ul>
			</div>
		</div>
		<div id="banner">
			<center><div id="form">
				<form action="UpdateDATA.php" method="post">
			<table style="color: black;">
				<tr>
					<td>BUILDING ID</td>
					<center><td width="100%" height="50px">
					<select name="bid">
						<option>UB01</option>
						<option>UB02</option>
					</select></center>
				</td>
				</tr>
				<tr>
					<td>Room ID</td>
				<!--	<td><input type="text" name="rno" placeholder="Enter Room No" title="Enter Room No" required></td>
				-->	
				<center><td width="100%" height="50px">
					<select name="rno" required>
						<option>10101</option>
						<option>10102</option>
						<option>10103</option>
						<option>10104</option>
						<option>10105</option>
						<option>20101</option>
						<option>20102</option>
						<option>20103</option>
						<option>20104</option>
						<option>20105</option>
					</select></center>
				</tr>
				
				<tr>
					<td>DATE</td>
					<td><input type="text" name="date" placeholder="Enter Date" title=" Enter Date" required></td>
					
				</tr>
				<tr>
					<td>Start Time</td>
				<!--	<td><input type="text" name="stime"></a>     -->
				<center><td width="100%" height="50px">
				<select name="stime" required>
						<option>8:00</option>
						<option>9:30</option>
						<option>11:00</option>
						<option>12:30</option>
						<option>2:00</option>
						<option>3:30</option>
						<option>5:00</option>
					</select></center>
					
				</tr>
				<tr>
					<td>End Time</td>
				<!--	<td><input type="text" name="etime"></a>  -->
				<center><td width="100%" height="50px">
				<select name="etime">
						<option>9:20</option>
						<option>10:50</option>
						<option>12:20</option>
						<option>1:50</option>
						<option>3:20</option>
						<option>4:50</option>
						<option>6:20</option>
					</select></center>
					
				</tr>
				<tr>
					<td>Section</td>
				<!--	<td><input type="number" name="sec" placeholder="Enter section No" title="Enter sec No"></td>
				-->
					<center><td width="100%" height="50px">
					<select name="sec" required>
						<option>01</option>
						<option>02</option>
						<option>03</option>
						<option>04</option>
						<option>05</option>
						<option></option>
					</select></center>
				</tr>
				<tr>
					<td>Course ID</td>
				<!--	<td><input type="text" name="cid" placeholder="Enter Course Id" title="Enter Course Id"></td>
				-->
					<center><td width="100%" height="50px">
					<select name="cid" required>
						<option>cse110</option>
						<option>cse220</option>
						<option>cse370</option>
						<option>cse341</option>
						<option>cse420</option>
						<option></option>
					</select></center>
				</tr>
				<tr>
					<td>Faculty ID</td>
					
				<!--	<td><input type="text" name="fid" placeholder="Enter faculty Id" title="Enter faculty Id"></td>
				-->	
					<td><input type="text" name="fid" value="<?php echo $_SESSION['un']; ?>" title="Enter faculty Id" required></td>
				</tr>
				<tr>
					<td>Room Booked</td>
				<td><input type="text" name="Rbk" placeholder="Enter Room Booked status" title=" Enter Room Booked status" required></td>
				</tr>
				
				<tr>
				<td>
					<td><input style="width: 120px; height: 30px; border-radius: 20px; opacity: 1" type="submit" name="submit" value="Update Regular"></td>
				</td>
				<td>
					<td><input style="width: 120px; height: 30px; border-radius: 20px; opacity: 1" type="submit" name="unbooked" value="Update unbooked"></td>
				</td>
				</tr>
			</table>
		</form>
		<?php
        if(isset($_POST['submit']))
        {
         	$bid=$_POST['bid'];
			$rno=$_POST['rno'];
         	$date=$_POST['date'];
         	$stime=$_POST['stime'];
			$etime=$_POST['etime'];
         	$sec=$_POST['sec'];
         	$cid=$_POST['cid'];
			$fid=$_POST['fid'];
         	$rbk=$_POST['Rbk'];
			//$rno2=$_POST['rno2'];
			//$stime2=$_POST['stime2'];
			//$sec2=$_POST['sec2'];
			
			$q1="select * from roominfo";
			//$q2="select * from unbookedroom";
			$run=mysqli_query($a,$q1);
			//$run2=mysqli_query($a,$q2);
			//$row=mysqli_fetch_array($run);
			//$status=$row['STATUS'];
			
			

			//if($run)
			//{
				//	if(mysqli_query($a,"update roominfo set BID='$bid',RID='$rno',DATE='$date',STIME='$stime',ETIME='$etime','SEC='$sec',CID='$cid',FID='$fid',STATUS='$rbk' where RID='$rno'")) //values('$bid','$rno','$date','$stime','$etime','$sec','$cid','$fid','$rbk')"))
					if(mysqli_query($a,"update roominfo set BID='$bid',RID='$rno',SEC='$sec',CID='$cid',FID='$fid',STATUS='$rbk',DATE='$date' where RID='$rno' AND STIME='$stime'"))
					{	
				echo '<script type="text/javascript">alert("Data updated in regular table!")</script>';
				}
				else
				{
				echo '<script type="text/javascript">alert("Data not updated in regular table!")</script>';	
				}
			//}
			//else
		//	{
		//			echo '<script type="text/javascript">alert("not running")</script>';
			//}
        }

		?>
		<?php
        if(isset($_POST['unbooked']))
        {
         	$bid=$_POST['bid'];
			$rno=$_POST['rno'];
         	$date=$_POST['date'];
         	$stime=$_POST['stime'];
			$etime=$_POST['etime'];
         	$sec=$_POST['sec'];
         	$cid=$_POST['cid'];
			$fid=$_POST['fid'];
         	$rbk=$_POST['Rbk'];
			//$rno2=$_POST['rno2'];
			//$stime2=$_POST['stime2'];
			//$sec2=$_POST['sec2'];
			
			//$q1="select * from roominfo";
			$q2="select * from unbookedroom";
			$run=mysqli_query($a,$q2);
			//$run2=mysqli_query($a,$q2);
			//$row=mysqli_fetch_array($run);
			//$status=$row['STATUS'];
			
			

			//if($run)
			//{
				//	if(mysqli_query($a,"update roominfo set RID='$rno',DATE='$date',STIME='$stime',ETIME='$etime','SEC='$sec',CID='$cid',FID='$fid',STATUS='$rbk' where RID='$rno'")) //values('$bid','$rno','$date','$stime','$etime','$sec','$cid','$fid','$rbk')"))
					if(mysqli_query($a,"update unbookedroom set BID='$bid'RID='$rno',SEC='$sec',CID='$cid',FID='$fid',BOOKEDFOR='$rbk',DATE='$date' where RID='$rno' AND STIME='$stime'"))
					{	
				echo '<script type="text/javascript">alert("Data updated UNBOOKED table!")</script>';
				}
				else
				{
				echo '<script type="text/javascript">alert("Data not updated in unbooked table!")</script>';	
				}
			//}
			//else
		//	{
		//			echo '<script type="text/javascript">alert("not running")</script>';
			//}
        }

		?>
					</div></center>
		</div>
	</div>
	</div>
	
  </div>
</body>

</html>