<!DOCTYPE html>
<html>
<head>
	<title>BMS</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
	
	
</head>
<body>
	<div id="full">
		<div  style="background-image: url('img/bms.jpg');background-size: 100% 710px; width: 100%; height: 710px">
		<div id="header">
			<div id="logo">
				<h1><font color="white">My Project</font></h1>
			</div>
			<div id="cl"><input type="button" name="btn" id="btn"></div>
			<div id="nav">
				<ul id="a1">
					<li><a href="#">Home</a></li>
					<li><a href="#">Contect Us</a></li>
					<li><a href="#">BOOK MY STAY</a></li>
					<li><a href="#">Our Hotel</a></li>
					<li><a href="#">Help</a></li>
				</ul>
			</div>
		</div>
		<div id="banner"></div>
	<center>
	<div style="background:rgba(255,255,255,.5); width: 80%;">
		
		<table>
			<tr>
				<th width="20%" height="50px">Destination</th>
				<th width="20%" height="50px">Chack In Date </th>
				<th width="20%" height="50px">Chack Out Date</th>
				<th width="20%" height="50px">Room</th>
				<td rowspan="2"><input type="submit" name="sub" value="Chack"></td>
			</tr>
			<tr>
				<td width="20%" height="50px"><center><input type="text" name="dest" placeholder="Enter Destination"></center></td>
				<td width="20%" height="50px"><center><input type="date" name="cin"></center></td>
				<td width="20%" height="50px"><center><input type="date" name="cout"></center></td>
				<td width="20%" height="50px">
					<center><select>
						<option>1</option>
						<option>2</option>
						<option>3</option>
						<option>4</option>
						<option>5</option>
					</select></center>
				</td>
			</tr>
		</table>
	
	</div>
	</center>
	</div>
  </div>
</body>

</html>