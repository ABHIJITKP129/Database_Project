﻿<?php
session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home (Room Management)</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
<!--	<script type="text/javascript" src="jquery/jquery.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#btn').click(function(){
				$('#nav').slideToggle();
			});
		});
	</script> -->

</head>
<body style="background-color:#bdc3c7">
	<div id="full">
		<div>
		<div id="header">
			<div id="logo">
				<h1><font color="white">Search</font></h1>
			</div>
			<div><button id="btn">|||</button></div>
			<div id="nav">
				<ul>
					<li><a href="ahome.php">Home</a></li>
				</ul>
			</div>
		</div>
	</div>
	</div>
	
	<div id="f1"><br><br><br><br><br><br><br><br><br><br><br><br>
	<center><p><b>SEARCH YOUR ROUTINE</b></p></center>
		<form action="searchResult.php" method="get">                     <!-------------ACTION AND METHOD IS HERE  wiil redirect from here -->
		<center><table>
			<tr>
			<!--	<th width="20%" height="50px">Destination</th>
				<!--<th width="20%" height="50px">ID</th>                
				<th width="20%" height="50px">Chack In Date</th>
				<th width="20%" height="50px">Chack Out Date</th>  -->
				<th width="20%" height="50px">COURSE ID</th>
				<th width="20%" height="50px">REASON</th>
				<td rowspan="2"><input type="submit" value="search" name="sub"></td>
			</tr>
			<tr>
			<!--	<td width="20%" height="50px"><center><input type="text" name="d1" placeholder="Enter Destination"></center></td>
			<!--	<td width="20%" height="50px"><center><input type="number" name="id"></center></td>                 will use later
				<td width="20%" height="50px"><center><input type="date" name="ci"></center></td>
				<td width="20%" height="50px"><center><input type="date" name="co"></center></td>-->
				<td width="20%" height="50px">
					<center><select name="cid">
					    <option></option>
						<option>cse110</option>
						<option>cse220</option>
						<option>cse341</option>
						<option>cse370</option>
						<option>cse420</option>
					</select></center>
				</td>
				<td width="20%" height="50px">
					<center><select name="status" required>
						<option>REGULAR-CLASS</option>
						<option>EXTRA-CLASS</option>
						<option>QUIZ</option>
						<option>SEMINAR</option>
						<option>WORKSHOP</option>
					</select></center>
				</td>
			</tr>
		</table></center>
	</form>
  </div>
</body>

</html>