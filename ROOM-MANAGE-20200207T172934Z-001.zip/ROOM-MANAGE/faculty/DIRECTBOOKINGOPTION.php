<?php
session_start();
include("connection.php");
$bid=$_GET['bid'];
$rno=$_GET['rno'];
//$stime=$_GET['stime'];
$date=$_GET['date'];
$stime=$_GET['stime'];
$etime=$_GET['etime'];
/*$sec=$_GET['sec'];
$cid=$_GET['cid'];
$fid=$_GET['fid'];
$rbk=$_GET['rbk'];*/
?>
<!DOCTYPE html>
<html>
<head>
	<title>Logged in as <?php echo $_SESSION['un']; ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
	
	
</head>
<body>
	<div id="full">
		<!--<div  style=background-size: 100% 710px; width: 100%; height: 710px">
	-->	<div id="header">
			<div id="logo">
			<h1><font color="white">DIRECT BOOKING OPTION</font></h1>
				
			</div>
			<div id="cl"><input type="button" name="btn" id="btn"></div>
			<div id="nav">
				<ul id="a1">
					<li><a href="ahome.php">Home</a></li>
					<li><a href="room.php">Room Update</a></li>
					<li><a href="booking.php">Booking</a></li>
					<li><a href="rd.php">Room Dateils</a></li>
					<li><a href="#">Help</a></li>
				</ul>
				<h1 style="color:blue;text-align: center; ">Welcome <?php echo $_SESSION['username']; ?></h1>
			</div>
		</div>
			<!-- <div id="banner"> -->
			<center><div id="form">
			<center><p><b>PLEASE FILL UP THE BLANK BOXES IN ORDER TO COFIRM BOOKING</b></p></center>
				<form action="DIRECTBOOKINGOPTION.php" method="post">
			<table style="color: black;">
				<tr>
					<td>BUILDING ID</td>
					<td><input type="text" name="BID" value="<?php echo $bid?>" title="Enter faculty Id"></td>
				</td>
				</tr>
				<tr>
					<td>Room ID</td>
				<!--	<td><input type="text" name="rno" placeholder="Enter Room No" title="Enter Room No" required></td>
				-->	
				<td><input type="text" name="RID" value="<?php echo $rno?>" title="Enter faculty Id"></td>
				</tr>
				
				<tr>
					<td>DATE</td>
					<td><input type="text" name="DATE" value="<?php echo $date?>" title="Enter faculty Id"></td>
					
				</tr>
				<tr>
					<td>Start Time</td>
				<!--	<td><input type="text" name="stime"></a>     -->
				<td><input type="text" name="STIME" value="<?php echo $stime?>" title="Enter faculty Id"></td>
					
				</tr>
				<tr>
					<td>End Time</td>
				<!--	<td><input type="text" name="etime"></a>  -->
				<td><input type="text" name="ETIME" value="<?php echo $etime?>" title="Enter faculty Id"></td>
					
				</tr>
				<tr>
					<td>Section</td>
				<!--	<td><input type="number" name="sec" placeholder="Enter section No" title="Enter sec No"></td>
				-->
					<center><td width="100%" height="50px">
					<select name="sec2">
					<option></option>
						<option>01</option>
						<option>02</option>
						<option>03</option>
						<option>04</option>
						<option>05</option>
						
					</select></center>
				</tr>
				<tr>
					<td>Course ID</td>
				<!--	<td><input type="text" name="cid" placeholder="Enter Course Id" title="Enter Course Id"></td>
				-->
					<center><td width="100%" height="50px">
					<select name="cid2">
					<option></option>
						<option>cse110</option>
						<option>cse220</option>
						<option>cse370</option>
						<option>cse341</option>
						<option>cse420</option>
						
					</select></center>
				</tr>
				<tr>
					<td>Faculty ID</td>
					
				<!--	<td><input type="text" name="fid" placeholder="Enter faculty Id" title="Enter faculty Id"></td>
				-->	
					<td><input type="text" name="fid2" value="<?php echo $_SESSION['username']; ?>" title="Enter faculty Id"></td>
				</tr>
				<tr>
					<td>Room Booked</td>
				<!--	<td><input type="text" name="Rbk" placeholder="Enter Room Booked status" title="Enter Room Booked status"></td>
				-->
						<center><td width="100%" height="50px">
					<select name="Rbk2" required>
					<option></option>
						<option>EXTRA-CLASS</option>
						<option>QUIZ</option>
						<option>SEMINAR</option>
						<option>WORKSHOP</option>
						
					</select></center>
				</tr>
				<tr>
				<td>
					<td><input style="width: 120px; height: 30px; border-radius: 20px; opacity: 1" type="submit" name="submit" value="submit"></td>
				</td>
				<!--<td>
					<td><input style="width: 120px; height: 30px; border-radius: 20px; opacity: 1" type="submit" name="submit" value="Update"></td>
				-->
				</td>
				</tr>
			</table>
		</form>
		
		<?php
        if(isset($_POST['submit']))
        {
         	$bid=$_POST['BID'];
			$rno=$_POST['RID'];
         	$date=$_POST['DATE'];
         	$stime=$_POST['STIME'];
			$etime=$_POST['ETIME'];
         	$sec=$_POST['sec2'];
         	$cid=$_POST['cid2'];
			$fid=$_POST['fid2'];
         	$rbk=$_POST['Rbk2'];
			
			$q1="select * from roominfo where RID='$rno' AND CID='$cid' AND STIME='$stime'";
			$q2="select * from unbookedroom where RID='$rno' AND CID='$cid' AND STIME='$stime'";
			$run=mysqli_query($a,$q1);
			$run2=mysqli_query($a,$q2);
			//$row=mysqli_fetch_array($run);
			//$status=$row['STATUS'];
			
			

			
		     /*   if(mysqli_num_rows($run2)>0)
				{
									
				echo '<script type="text/javascript">alert("This slot Already exists in unbookedRoom.. Please try another ID!")</script>';
				}*/
				if(mysqli_query($a,"insert into newbooking(BID,RID,DATE,STIME,ETIME,SEC,CID,FID,STATUS) values('$bid','$rno','$date','$stime','$etime','$sec','$cid','$fid','$rbk')"))
				{
					if(mysqli_query($a,"DELETE from unbookedroom WHERE RID='$rno' AND STIME='$stime'"))//"update unbookedroom set BOOKEDFOR='unbook' where RID=$rno"))
                   {

						//echo "data inserted";
						echo '<script type="text/javascript">alert("Data inserted in newbookingtable!")</script>';
						echo("<script>window.location.href = 'newBooking.php';</script>");
					}
				}
				else
				{
					echo '<script type="text/javascript">alert("Data not inserted in newbooking!")</script>';
				}
								
		  /*  else if($rbk=="EXTRA-CLASS" || $rbk=="SEMINAR" || $rbk=="UNBOOKED" || $rbk=="QUIZ" || $rbk=="WORKSHOP")
			{
				if(mysqli_num_rows($run)>0)
				{
									
				echo '<script type="text/javascript">alert("This slot Already exists in regula class.. Please try another ID!")</script>';
				}
				else if(mysqli_query($a,"insert into unbookedroom(BID,RID,DATE,STIME,ETIME,SEC,CID,FID,BOOKEDFOR) values('$bid','$rno','$date','$stime','$etime','$sec','$cid','$fid','$rbk')"))
				{
					/*if(mysqli_query($a,"update unbookedroom set SEC='$sec',CID='$cid',FID='$fid',BOOKEDFOR='$rbk',DATE='$date' where RID='$rno' AND STIME='$stime' AND SEC='$sec'")) //values('$bid','$rno','$date','$stime','$etime','$sec','$cid','$fid','$rbk')"))
					{*/	
			//	echo '<script type="text/javascript">alert("Data inserted in unbooketable!")</script>';
				}
			//	else
			//	{
					//echo '<script type="text/javascript">alert("Data not inserted?????!")</script>';
			//	}
			//}
       // }*/

		?>
					</div></center>
		</div>
		
		
  </div>
</body>

</html>