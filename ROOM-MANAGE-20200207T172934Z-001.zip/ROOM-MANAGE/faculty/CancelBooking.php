<?php
include("connection.php");
$bid=$_GET['bid'];
$rno=$_GET['rno'];
//$stime=$_GET['stime'];
$date=$_GET['date'];
$stime=$_GET['stime'];
$etime=$_GET['etime'];
$sec=$_GET['sec'];
$cid=$_GET['cid'];
$fid=$_GET['fid'];
$rbk=$_GET['rbk'];


if(mysqli_query($a,"insert into unbookedRoom(BID,RID,DATE,STIME,ETIME,SEC,CID,FID,BOOKEDFOR) values('$bid','$rno','$date','$stime','$etime','NULL','NULL','NULL','UNBOOKED?')"))
				
{
	
	  header("Location:ahome.php");
	//echo("<script>window.location.href = 'unbookedRoom.php';</script>");
}
if(mysqli_query($a,"DELETE from newbooking WHERE RID='$rno' AND STIME='$stime'"))//"update unbookedroom set BOOKEDFOR='unbook' where RID=$rno"))
{
}
?>