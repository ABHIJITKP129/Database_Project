<?php
include("connection.php");
// $r=$_GET['room'];
//$ci=$_GET['ci'];
//$co=$_GET['co'];
$cid=$_GET['cid'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home (Hotel Management)</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
</head>
<body>
	<div id="full">
		<div id="bg" style="background-image: url('img/bed.jpg'); height: 1200px;">
 	<div id="header">
			<div id="logo">
				<h1><font color="white">My Project</font></h1>
			</div>
			<div id="nav">
				<ul>
					<li><a href="#">Home</a></li>
					<li><a href="#">Contect Us</a></li>
					<li><a href="#">BOOK MY STAY</a></li>
					<li><a href="#">Our Hotel</a></li>
					<li><a href="r1.php">Search Result</a></li>
				</ul>
			</div>
		</div>
		<div id="banner">
			<div id="form">
				<form action="r1.php" method="post">
			<table style="color: yellow;">
				<?php
				  $q1="select * from roominfo where CID='$cid'";
                        $run=mysqli_query($a,$q1);
                        $row=mysqli_fetch_array($run);
                        $cidfromtable=$row['CID'];
						echo $cidfromtable; //will show the room number;
                        $q="select * from room where status='unbook'";
                        $run=mysqli_query($a,$q);
                        $num=mysqli_num_rows($run);/*num*/
						if($run)
						{
							echo "this run is working";
                        echo "$cidfromtable";
						}
                        if($cidfromtable==$cid)       //<---------------comparing here that existing room and order room 
                        {
                        	?>
                        	<tr>
					<td>Status</td>
					<td><input type="text" name="Status" value="Available-class" disabled="disabled" title="Status"></td>
				</tr>
				<tr>
			<div style="background-color: rgba(255,255,255,0.6);">
			<table>
				<tr>
				    <th width="10%" height="50px">BID</th>
					<th width="10%" height="50px">RID</th>
                     <th width="10%" height="50px">DATE</th>
                     <th width="10%" height="50px">STIME</th>
                     <th width="10%" height="50px">ETIME</th>
					 <th width="10%" height="50px">SEC</th>
                     <th width="10%" height="50px">CID</th>
                     <th width="10%" height="50px">FID</th>
                     <th width="10%" height="50px">STATUS</th>
					 <th width="10%" height="50px">DELETE</th>
					 <th width="10%" height="50px">Cancel Booking</th>
				</tr>
				<?php
                 $q1="select * from roominfo where CID='$cid'";
                 $run3=mysqli_query($a,$q1);
                 while($row2=mysqli_fetch_array($run3))
                 {
					$bid=$row2['BID'];
					$rno=$row2['RID'];
					$date=$row2['DATE'];
					$stime=$row2['STIME'];
					$etime=$row2['ETIME'];
					$sec=$row2['SEC'];
					$cid=$row2['CID'];
					$fid=$row2['FID'];
					$rbk=$row2['STATUS'];
                ?>

				<tr>
				     <td width="10%" height="50px"><center><?php echo $bid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $rno; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $date; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $stime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $etime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $sec; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $cid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $fid; ?><center></td>
					<td width="10%" height="50px"><center><?php echo $rbk; ?><center></td>
					<td><a style="color: blue" href="deleteEXTRAbook.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>">Delete row Completyly</a> </td>
					<td><a style="color: blue" href="CancelBooking.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>&bid=<?php echo $bid;?>&date=<?php echo $date;?>&etime=<?php echo $etime;?>&sec=<?php echo $sec;?>&fid=<?php echo $fid;?>&cid=<?php echo $cid;?>&rbk=<?php echo $rbk;?>">Cancel Booking</a> </td>										
		            
				</tr>
				<?php
				  }
				?>
			</table>
		</center>
		</div>
	<center>
	
	</center>
	</div>
                    <?php    }
                    else              //<---------if order room is much more than existing room then we will show not available.
                    {
                    	?>
                           <tr>
					<td>Status</td>
					<td><input type="text" name="Status" value="Not-Available" disabled="disabled" title="Status"></td>
				</tr>          
                    	<?php
                    }
				
				?>
				
				
			</table>
		</form>
		<?php
       if(isset($_POST['submit']))
        {
        	$name=$_POST['name'];
        	$idno=$_POST['idno'];
            $city=$_POST['city'];
        	$dis=$_POST['dis'];
        	$state=$_POST['state'];
           $email=$_POST['email'];
            $coin=$_POST['coin'];
        	$coout=$_POST['coout'];
        		$m=$_POST['members'];


        		if(mysqli_query($a,"insert into f1(name,city,dis,email,state,cidate,codate,m,idno) value('$name','$city','$dis','$email','$state','$coin','$coout','$m','$idno')"))
        		{
        			mysqli_query($a,"update room set status='Book' where rno=$rno");
        			header("Location:fi.php");
        		}
        		else
        		{
        			echo "data not insert";
        		}
       }
       
		?>			</div>
		</div>
	</div>
	</div>
	
  </div>
</body>

</html>