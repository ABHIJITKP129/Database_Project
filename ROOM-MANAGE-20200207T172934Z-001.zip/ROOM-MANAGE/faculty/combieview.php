<?php
session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Logged in as <?php echo $_SESSION['un']; ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
	
	
</head>
<body>
	<div id="full">
		<div  style="background-image: url('img/bu.jpg');background-size: 100% 710px; width: 100%; height: 710px">
		<div id="header">
			<div id="logo">
				<h1><font color="white">ROOMS WITH BUILDING LOCATION</font></h1>
			</div>
			<div id="cl"><input type="button" name="btn" id="btn"></div>
			<div id="nav">
				<ul id="a1">
					<li><a href="ahome.php">Home</a></li>
					<li><a href="RegularRoutine.php">Routine</a></li>
					<li><a href="unbookedRoom.php">Unbooked Rooms</li>
					<li><a href="newBooking.php">New Booking Rooms</li>
					<li><a href="combieview.php">Combined view</li>
				</ul>
			</div>
		</div>
		<div id="banner"><br><br><br><br><br><br><br><br><br><br><br>
			<h1 style="color:blue;text-align: center; ">Welcome Admin</h1>
			<div style="background-color: rgba(255,255,255,0.6);">
			<table>
				<tr>
					<th width="10%" height="50px">BID</th>
                     <th width="10%" height="50px">LOCATION</th>
					<th width="10%" height="50px">RID</th>
                     <th width="10%" height="50px">DATE</th>
                     <th width="10%" height="50px">STIME</th>
                     <th width="10%" height="50px">ETIME</th>
					 <th width="10%" height="50px">SEC</th>
                     <th width="10%" height="50px">CID</th>
                     <th width="10%" height="50px">FID</th>
                     <th width="10%" height="50px">STATUS</th>
				</tr>
				<?php
                 $q1="select buildinginfo.BID,buildinginfo.Location,RID,DATE,STIME,ETIME,SEC,CID,FID,STATUS FROM buildinginfo,roominfo where buildinginfo.BID=roominfo.BID";
                 $run=mysqli_query($a,$q1);
                 while($row=mysqli_fetch_array($run))
                 {
					$bid=$row['BID'];
					$loc=$row['Location'];	
					$rno=$row['RID'];
					$date=$row['DATE'];
					$stime=$row['STIME'];
					$etime=$row['ETIME'];
					$sec=$row['SEC'];
					$cid=$row['CID'];
					$fid=$row['FID'];
					$rbk=$row['STATUS'];
                ?>

				<tr>
					<td width="10%" height="50px"><center><?php echo $bid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $loc; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $rno; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $date; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $stime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $etime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $sec; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $cid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $fid; ?><center></td>
					<td width="10%" height="50px"><center><?php echo $rbk; ?><center></td>
					
				</tr>
				<?php
				  }
				?>
			</table>
		</center>
		</div>
	<center>
	
	</center>
	</div>
  </div>
</body>

</html>