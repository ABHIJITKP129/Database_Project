<?php
 session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Logged in as <?php echo $_SESSION['username']; ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
	
	
</head>
<body>
	<div id="full">
		<div  style="background-image: url('img/bu.jpg');background-size: 100% 710px; width: 100%; height: 710px">
		<div id="header">
			<div id="logo">
				<h1><font color="white">FACULTY Home</font></h1>
			</div>
			<div id="cl"><input type="button" name="btn" id="btn"></div>
			<div id="nav">
				<ul id="a1">
					<li><a href="http://localhost/ROOM-MANAGE/index.php">Home</a></li>
					<li><a href="RegularRoutine.php">Routine</a></li>
					<li><a href="unbookedRoom.php">Unbooked Rooms</li>
					<li><a href="newBooking.php">New Booking</li>
					<li><a href="combieview.php">Combined view</li>
					<li><a href="DOsearch.php">Do Search</a></li> 
				<!--	<li><a href="DIRECTBOOKINGOPTION.php">DBN</a></li>
				-->	<li><form > <!--action="ahome.php" method="post"> -->
					<input name="logout" type="submit" id="logout_btn" value="Log Out"/>
					</form><li>
				</ul>
			</div>
				
					
					
			
		</div>
	
		<div id="banner"><br><br><br><br><br><br><br><br><br><br><br>
			<h1 style="color:blue;text-align: center; ">Welcome  <?php echo $_SESSION['username']; ?></h1>
		<!--	<div id="f1">
		<form action="search.php" method="get">                     <!-------------ACTION AND METHOD IS HERE   
		<center><table>
			<tr>
				<th width="20%" height="50px">Destination</th>
				<!--<th width="20%" height="50px">ID</th>-->                <!--this was just a test line so wll use later
				<th width="20%" height="50px">Chack In Date</th>
				<th width="20%" height="50px">Chack Out Date</th>
				<th width="20%" height="50px">Room</th>
				<td rowspan="2"><input type="submit" value="Check" name="sub"></td>
			</tr>
			<tr>
				<td width="20%" height="50px"><center><input type="text" name="d1" placeholder="Enter Destination"></center></td>
			<!--	<td width="20%" height="50px"><center><input type="number" name="id"></center></td>                 will use later
				<td width="20%" height="50px"><center><input type="date" name="ci"></center></td>
				<td width="20%" height="50px"><center><input type="date" name="co"></center></td>
				<td width="20%" height="50px">
					<center><select name="room">
						<option>1</option>
						<option>2</option>
						<option>3</option>
						<option>4</option>
						<option>5</option>
					</select></center>
				</td>
			</tr>
		</table></center>
	</form>     
		</div>  -->
	<?php
	
			if(isset($_POST['logout']))         //clicking the logout button will the end the session whichi startd after login with username
			{
				session_destroy();
				echo '<script type="text/javascript">alert("log out pressed")</script>';	
				header('location:http://localhost/ROOM-MANAGE/index.php');
				//echo("<script>window.location.href = 'index.php';</script>");
			}
			//echo '<script type="text/javascript">alert("log out pressed")</script>';
			?>
	
	</div>
	
  </div>
</body>

</html>