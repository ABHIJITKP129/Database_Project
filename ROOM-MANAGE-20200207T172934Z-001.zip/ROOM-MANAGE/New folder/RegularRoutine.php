<?php
session_start();
include("connection.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>BRACU ROOM MANAGEMENT</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="img/LOGO.png" type="img/icon" rel="icon">
	<script type="text/javascript" src="jquery/jquery.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#btn').click(function(){
				$('#nav').slideToggle();
			});
		});
	</script>
	
</head>
<body>
	<div id="full">
		<div  style="background-color:#bdc3c7; background-size: 100% 710px; width: 100%; height: 1450px">
		<div id="header">
			<div id="logo">
				<h1><font color="white">Welcome!!</font></h1>
			</div>
			<div id="cl"><input type="button" name="btn" id="btn"></div>
			<div id="nav">
				<ul id="a1">
					<li><a href="#">Home</a></li>
					<li><a href="DOsearch.php">Do Search</a></li> 
					<li><a href="login.php">login</a></li>
					<li><a href="register.php">Register</a></li>
				</ul>
			</div>
		</div>
		<div id="banner"><br><br><br><br><br><br><br><br><br><br><br>
			<h1 style="color:red;text-align: center; ">ROUTINE</h1>
			<div style="background-color: rgba(255,255,255,0.6);">
			<table>
				<tr>
				    <th width="10%" height="50px">BID</th>
					<th width="10%" height="50px">RID</th>
                     <th width="10%" height="50px">DATE</th>
                     <th width="10%" height="50px">STIME</th>
                     <th width="10%" height="50px">ETIME</th>
					 <th width="10%" height="50px">SEC</th>
                     <th width="10%" height="50px">CID</th>
                     <th width="10%" height="50px">FID</th>
                     <th width="10%" height="50px">STATUS</th>
					  <th width="10%" height="50px"><b>DELETE DATA</b></th>
				</tr>
				<?php
                 $q1="select * from roominfo";
                 $run=mysqli_query($a,$q1);
                 while($row=mysqli_fetch_array($run))
                 {
					$bid=$row['BID'];
					$rno=$row['RID'];
					$date=$row['DATE'];
					$stime=$row['STIME'];
					$etime=$row['ETIME'];
					$sec=$row['SEC'];
					$cid=$row['CID'];
					$fid=$row['FID'];
					$rbk=$row['STATUS'];
                ?>

				<tr>
				     <td width="10%" height="50px"><center><?php echo $bid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $rno; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $date; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $stime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $etime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $sec; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $cid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $fid; ?><center></td>
					<td width="10%" height="50px"><center><?php echo $rbk; ?><center></td>
					<td><a style="color: blue" href="deleteData.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>">Delete row Completyly</a> </td>
					
				</tr>
				<?php
				  }
				?>
			</table>
		</center>
		</div>
	<center>
	
	</center>
	</div>
	
	
	<div id="banner"><br><br><br><br><br><br><br><br><br><br><br>
			<h1 style="color:blue;text-align: center; ">EXTRA SCHEDULE</h1>
			<div style="background-color: rgba(255,255,255,0.6);">
			<table>
				<tr>
				    <th width="10%" height="50px">BID</th>
					<th width="10%" height="50px">RID</th>
                     <th width="10%" height="50px">DATE</th>
                     <th width="10%" height="50px">STIME</th>
                     <th width="10%" height="50px">ETIME</th>
					 <th width="10%" height="50px">SEC</th>
                     <th width="10%" height="50px">CID</th>
                     <th width="10%" height="50px">FID</th>
                     <th width="10%" height="50px">STATUS</th>
					 <th width="10%" height="50px">DELETE</th>
					 <th width="10%" height="50px">Cancel Booking</th>
				</tr>
				<?php
                 $q1="select * from newbooking";
                 $run=mysqli_query($a,$q1);
                 while($row=mysqli_fetch_array($run))
                 {
					$bid=$row['BID'];
					$rno=$row['RID'];
					$date=$row['DATE'];
					$stime=$row['STIME'];
					$etime=$row['ETIME'];
					$sec=$row['SEC'];
					$cid=$row['CID'];
					$fid=$row['FID'];
					$rbk=$row['STATUS'];
                ?>

				<tr>
				     <td width="10%" height="50px"><center><?php echo $bid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $rno; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $date; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $stime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $etime; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $sec; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $cid; ?></center></td>
					<td width="10%" height="50px"><center><?php echo $fid; ?><center></td>
					<td width="10%" height="50px"><center><?php echo $rbk; ?><center></td>
					<td><a style="color: blue" href="deleteEXTRAbook.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>">Delete row Completyly</a> </td>
					<td><a style="color: blue" href="CancelBooking.php? rno=<?php echo $rno;?>&stime=<?php echo $stime;?>&bid=<?php echo $bid;?>&date=<?php echo $date;?>&etime=<?php echo $etime;?>&sec=<?php echo $sec;?>&fid=<?php echo $fid;?>&cid=<?php echo $cid;?>&rbk=<?php echo $rbk;?>">Cancel Booking</a> </td>										
		            
				</tr>
				<?php
				  }
				?>
			</table>
		</center>
		</div>
	<center>
	
	</center>
	</div>
	
	
	
	
  </div>
</body>

</html>